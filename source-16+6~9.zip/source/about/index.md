---
title: about
date: 2016-06-17 16:06:51
---

#             about me

Yan_1_20,学习逆向编程漏洞的新人
主要学习研究方向android底层相关，
对漏洞挖掘有着浓厚兴趣

YT
爱好软件，爱好底层安全<br>
<br>
　　　　　　　　　　　　　　　　　银河星爆！

![](/image/about2.jpg)
